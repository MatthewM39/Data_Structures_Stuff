#ifndef ACTOR
#define ACTOR
#include "CConsole.h"

class Game;

class Actor{

protected:
	char toDisplay; // char to display

	Color dColor, bgColor;

	enum Direction { None, Up, Down, Left, Right }; // possible directions for the actor

	int xPos, yPos; // x and y coords for actor

	Direction myDirection; // current direction of the actor

	Game * myGame; // pointer to game, needs to be protected so its children can use it

	void setDisplayChar(char ch); // modify the display char

	void setX(int x); // set x coord

	void setY(int y); // set y coord

	void resetDir(); // reset actor direction to None

	virtual void move(); // move the actor... different for monsters and player

	void setDirection(Direction d); // set the actor direction

public:
	Actor(Game * game); // constructor sets myGame equal to game

	int getX() const; // return x

	int getY() const; // return y

	Color getColor() const; // get the color

	Color getBgColor() const; // get the background color

	char getDisplayChar() const; // get char displayed by an actor

	Direction getDirection() const; // return the current direction

};
#endif