#ifndef MAZE
#define MAZE
#include "CConsole.h"
#include <fstream>
#include <String>
using std::string;

class Game;

class Maze {

public:
	Maze(CConsole * console); // maze constructor. set myConsole to the passed pointer

	~Maze(); // maze destructor. can be left as default

	bool loadMaze(const string &fileName); // load the maze from a given file. increments pelletNumber for each pellet

	void display(); // display the given maze

	int getPlayerStartX() const; // get the player starting x coord

	int getPlayerStartY() const; // get the player starting y coord

	int getMonsterStartX() const; // get monster spawn x coord

	int getMonsterStartY() const; // get monster spawn y coord

	void resetDispay(); // reset the display. move monsters and player to starting positions.

	bool done(); // checks to see if pelletNumber is 0

	char getMazeValue(int x, int y) const; // get the char value at a specific point

	void clearMazePosition(int x, int y); // clear the maze at a position and decrement pelletNumber

private:
	CConsole * myConsole; // pointer to game's console
	char myDisplay[23][21]; // 2D char array to hold the maze
	int pelletNumber; // number of pellets
	int playerStartX, playerStartY, monsterStartX, monsterStartY;
};
#endif