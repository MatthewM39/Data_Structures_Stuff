#ifndef PLAYER
#define PLAYER
#include "Actor.h"

class Game;

class Player : public Actor {

public:

	
	Player(Game * game); // constructor needs to set myGame equal to game, lives to 3, score to 0

	~Player(); // destructor. can be left as default because no dynamic memory used

	int getLives() const; // get number of lives

	int getScore() const; // return score

	void decreaseLives(); // decrement lives by 1
	void move(); 
	
private:
	int lives; // store number of lives
	int score; // player score
	CConsole * myConsole;
};

#endif
