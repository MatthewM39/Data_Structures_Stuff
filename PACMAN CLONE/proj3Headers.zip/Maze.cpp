#include "Maze.h"
#include "Game.h"
using namespace std;

Maze::Maze(CConsole * console) {
	myConsole = console;
} 

bool Maze::loadMaze(const string &fileName) {
	ifstream input;
	input.open(fileName); // attempt to open the file
	if (!input.is_open()) // make sure the file opens
		return false;
	string myString;
	int i = 0;
	while (i <mazeY) { // go through the file until the maze height is reached
		getline(input, myString); // get the line as a string
		for (int j = 0; j < mazeX; j++) { // convert to char array
			if (myString[j] == '@') { // if @ is found set player spawn coords
				playerStartX = j;
				playerStartY = i;
			}
			else if (myString[j] == '$') { // if $ is found set monster spawn coords
				monsterStartX = j;
				monsterStartY = i;
			}
			else
				myDisplay[j][i] = myString[j]; // otherwise, insert the char into the array
		}
		i++;
	}
	input.close();
	return true;
}

void Maze::display(){
	for (int i = 0; i < mazeX; i++) {
		for (int j = 0; j < mazeY; j++) {
			if (myDisplay[i][j] == '#' || myDisplay[i][j] == '*' || myDisplay[i][j] == '.') // if a wall char is found, need to print it
				myConsole->printChar(i, j, myDisplay[i][j]);
		}
	}
}

int Maze::getPlayerStartX() const{
	return playerStartX;
}

int Maze::getPlayerStartY() const {
	return playerStartY;
}

int Maze::getMonsterStartX() const
{
	return monsterStartX;
}

int Maze::getMonsterStartY() const
{
	return monsterStartY;
}

void Maze::resetDispay()
{
	// IDK 
}

bool Maze::done()
{
	if (pelletNumber == 0)	return true;
	return false;
}

char Maze::getMazeValue(int x, int y) const
{
	return myDisplay[x][y];
}

void Maze::clearMazePosition(int x, int y){
	myDisplay[x][y] = ' ';
	pelletNumber--;
	myConsole->printChar(x, y, ' ');
}

