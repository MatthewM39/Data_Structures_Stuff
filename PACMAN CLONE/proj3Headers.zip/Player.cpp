#include "Game.h"
#include "Player.h"
#include "Actor.h"

Player::Player(Game * game) : Actor(game){
	lives = 3;
	score = 0;
}

int Player::getLives() const{
	return lives;
}

int Player::getScore() const
{
	return score;
}

void Player::decreaseLives(){
	lives--;
}

void Player::move() {
	char temp;

	if (myGame->getCharInput(temp)) {
		if (temp == '4')	this->setDirection(Actor::Left);
		else if (temp == '6')	this->setDirection(Actor::Right);
		else if (temp == '8')	this->setDirection(Actor::Up);
		else if (temp = '2')	this->setDirection(Actor::Down);
	}

	if (myDirection == Left) {
		if (myGame->getMazeContents(xPos - 1, yPos) !=  '#'){
			xPos = -1;
		}
	}

	else if (myDirection == Right) {
		if (myGame->getMazeContents(xPos + 1, yPos) != '#') {
			xPos = +1;
		}
	}

	else if (myDirection == Up) {
		if (myGame->getMazeContents(xPos, yPos + 1) != '#') {
			yPos =+ 1;
		}
	}

	else if (myDirection == Down) {
		if (myGame->getMazeContents(xPos, yPos - 1) != '#') {
			yPos =- 1;
		}
	}
}
