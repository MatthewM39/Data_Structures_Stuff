#include "Game.h"
#include "CConsole.h"
#include "Actor.h"
#include "Maze.h"
#include "Player.h"

Game::Game(int delay){
	myConsole = new CConsole(x, y);
	myPlayer = new Player(this);
}

Game::~Game(){
	delete myConsole;
	delete myPlayer;
}

void Game::run() {

	while (myMaze->loadMaze("MAZE0.TXT") && myPlayer->getLives() > 0) {
		myMaze->display();
		while (!myMaze->done() && myPlayer->getLives() > 0) {
			myPlayer->move();
		}
		level++;

	}

}

int Game::getLevel() const{
	return level;
}

int Game::getPlayerX() const{
	return myPlayer->getX();
}

int Game::getPlayerY() const {
	return myPlayer->getY();
}

void Game::killPlayer(){
	myPlayer->decreaseLives();
}

void Game::makeMonstersVulnerable(){
	// DOES NOTHING CURRENTLY SHOULD SWAP ALL THE MONSTERS TO VULNERABLE ONCE IMPLEMENTED

}

void Game::clearMazePosition(int x, int y){
	myMaze->clearMazePosition(x, y);
}

char Game::getMazeContents(int x, int y) const{
	return myMaze->getMazeValue(x,y);
}

void Game::displayInfo(){
	// NEED TO IMPLEMENT
}

bool Game::getCharInput(char& temp){
	return myConsole->getInput(temp);
}
