#include "Actor.h"
#include "Game.h"

void Actor::setDisplayChar(char ch){
	toDisplay = ch;
}

void Actor::setX(int x){
	xPos = x;
}

void Actor::setY(int y) {
	yPos = y;
}

void Actor::resetDir(){
	myDirection = None;
}

void Actor::setDirection(Direction d){
	myDirection = d;
}

Actor::Actor(Game * game){
	myGame = game;
}

int Actor::getX() const {
	return xPos;
}

int Actor::getY() const{
	return yPos;
}

Color Actor::getColor() const{
	return dColor;
}

Color Actor::getBgColor() const{
	return bgColor;
}

char Actor::getDisplayChar() const{
	return toDisplay;
}

Actor::Direction Actor::getDirection() const{
	return myDirection;
}


