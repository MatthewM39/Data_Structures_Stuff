#ifndef GAME
#define GAME


const int mazeY = 21;	// constants for maze size
const int mazeX = 23; 
const int y = 60;	// total cconsole size
const int x = 24;

class CConsole;
class Actor;
class Player;
class Maze;

class Game {
public:

	/*
	Needs to set the delay time
	The game constructor needs to create the CConsole, Maze, and Actors. 
	The actors must be passed a pointer to "this" of the current Game.
	*/
	Game(int delay); 

	~Game(); // free up memory by deleting dynamic memory created



	void run(); 

	int getLevel() const; // return the current level number

	int getPlayerX () const; // return the player's x coord myPlayer.getX()

	int getPlayerY() const; // return the player's y coord myPlayer.getY()



	/* killPlayer needs to call myPlayer.decreaseLives()
		if myPlayer.getLives() is equal to 0, the game ends
	*/
	void killPlayer(); 

	// Needs to call .setState() on all four monsters and set them to vulnerable
	void makeMonstersVulnerable(); 

	// need to call the maze's clearMazePosition
	void clearMazePosition(int x, int y); 

	// get the value at a coordinate. use maze's getMazeValue
	char getMazeContents(int x, int y) const; 

	// needs to display lives, level, and score at the bottom. access lives and score from myPlayer
	void displayInfo();

	bool getCharInput(char& temp);


private:
	CConsole * myConsole; // pointer to game's console
	Maze * myMaze; // pointer to a maze
	int level = 0; // level counter
	char fileName[15]; // the filename
	int delay;
	Player * myPlayer;
	
	// needs to also have the four monsters in Project 4
};

#endif 
